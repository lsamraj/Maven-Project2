package com.pages;

import com.base.TestBase;

public class HomePage extends TestBase{

}
