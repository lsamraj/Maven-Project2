package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base.TestBase;

public class LoginPage extends TestBase{

	@FindBy(name="email")
	WebElement username;
	
	@FindBy(name="passwd")
	WebElement password;
	
	@FindBy(id="SubmitLogin")
	WebElement loginbutton;
	
	public LoginPage() {
		PageFactory.initElements(driver,this);
		//driver.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
	}
	
	public String validateloginpagetitle() {
		return driver.getTitle();
	}
	public HomePage login(String un, String pwd)
	{
		username.sendKeys(un);
		password.sendKeys(pwd);
		driver.manage().timeouts().implicitlyWait(3000,TimeUnit.SECONDS);
		loginbutton.click();
		return new HomePage();
	}
}
